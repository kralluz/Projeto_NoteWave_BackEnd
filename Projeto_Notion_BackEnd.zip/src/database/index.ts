import client from "./config";
import startDatabase from "./connection";

export { client, startDatabase };
